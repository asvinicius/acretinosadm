<?php
class LoginModel extends CI_Model{
	
    public function search($email, $password){
        $this->db->where("superemail", $email);
        $this->db->where("superpassword", $password);
        
        return $this->db->get("super")->row_array();
    }
	
}
